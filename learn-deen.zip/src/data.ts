import { Dua } from "./types";

export const DUAS: Dua[] = [
  {
    id: "1",
    category: "Morning",
    arabic: "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللهُ وَحْدَهُ لَا شَرِيكَ لَهُ",
    transliteration: "Asbahna wa asbahal-mulku lillah, walhamdu lillah, la ilaha illallahu wahdahu la sharika lah",
    translation: "We have entered upon the morning and the whole kingdom of Allah has entered upon the morning as well. All praise is for Allah. There is no god but Allah, alone, without any partner.",
    reference: "Muslim"
  },
  {
    id: "2",
    category: "Evening",
    arabic: "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللهُ وَحْدَهُ لَا شَرِيكَ لَهُ",
    transliteration: "Amsayna wa amsayal-mulku lillah, walhamdu lillah, la ilaha illallahu wahdahu la sharika lah",
    translation: "We have entered upon the evening and the whole kingdom of Allah has entered upon the evening as well. All praise is for Allah. There is no god but Allah, alone, without any partner.",
    reference: "Muslim"
  },
  {
    id: "3",
    category: "Before Sleep",
    arabic: "بِاسْمِكَ رَبِّي وَضَعْتُ جَنْبِي، وَبِكَ أَرْفَعُهُ",
    transliteration: "Bismika Rabbi wada'tu janbi, wa bika arfa'uh",
    translation: "In Your name, my Lord, I lie down and in Your name I rise.",
    reference: "Al-Bukhari & Muslim"
  },
  {
    id: "4",
    category: "After Prayer",
    arabic: "أَسْتَغْفِرُ اللهَ (ثَلَاثاً) اللَّهُمَّ أَنْتَ السَّلَامُ، وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ",
    transliteration: "Astaghfirullah (3 times). Allahumma Antas-Salamu wa minkas-salamu, tabarakta ya Dhal-Jalali wal-Ikram",
    translation: "I ask Allah for forgiveness (3 times). O Allah, You are Peace and from You comes peace. Blessed are You, O Owner of majesty and honor.",
    reference: "Muslim"
  },
  {
    id: "5",
    category: "Protection",
    arabic: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ",
    transliteration: "Bismillahi-lladhi la yadurru ma'as-mihi shay'un fil-ardi wa la fis-sama'i wa Huwas-Sami'ul-'Alim",
    translation: "In the Name of Allah, Who with His Name nothing can cause harm in the earth nor in the heavens, and He is the All-Hearing, the All-Knowing.",
    reference: "Abu Dawud & At-Tirmidhi"
  }
];
